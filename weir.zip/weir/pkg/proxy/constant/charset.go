package constant

import "github.com/pingcap/parser/charset"

const (
	DefaultCharset = charset.CharsetUTF8MB4
	DefaultCollationID = charset.CollationUTF8MB4
)