package constant

const ContextKeyPrefix = "__w_"

const ContextKeySessionVariable = ContextKeyPrefix + "session_sysvars"
