# Contribution Guide

Please refer to PingCAP [CONTRIBUTING.md](https://github.com/pingcap/community/blob/master/CONTRIBUTING.md)