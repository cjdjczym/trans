# 监控与告警

## Grafana监控

Grafana监控分为proxy级别和namespace级别, [这里](assets/grafana_proxy.json) 给出了一个proxy级别监控大盘的配置示例.
